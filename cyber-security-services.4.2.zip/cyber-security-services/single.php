<?php
/**
 * The template for displaying all single posts
 * 
 * @subpackage Cyber Security Services
 * @since 1.0
 */

get_header(); ?>
<?php get_template_part( 'template-parts/post/single-page' ) ?>
<?php get_footer();